-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 15 déc. 2024 à 19:45
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestion_produits`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `libelle` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`id`, `libelle`) VALUES
(1, 'electronique '),
(2, 'aliments'),
(3, 'shoppings'),
(6, 'meubles');

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `prix` decimal(10,2) DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL,
  `id_categorie` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`id`, `nom`, `description`, `prix`, `quantite`, `id_categorie`) VALUES
(1, 'telephone', 'marque Iphone 13', '250.00', 2, 1),
(2, 'telephone', 'Samsung A55 S', '300.00', 1, 1),
(3, 'telephone ', 'Samsung Galaxy ', '255.00', 1, 1),
(4, 'Casque ', 'P47', '4.00', 3, 1),
(5, 'Ecouteur', 'Iphone', '3.00', 3, 1),
(6, 'Ecouteur', 'Samsung', '2.00', 5, 1),
(7, 'Sucre', 'Menthe ( 1kg)', '1.00', 1, 2),
(8, 'Sucre', 'Cristal ( 1kg)', '1.00', 1, 2),
(9, 'sac', 'a main', '50.00', 1, 3),
(10, 'montre', 'connecté', '50.00', 1, 1),
(12, 'tee shirts', 'unique', '3.00', 1, 3),
(14, 'telephone', 'samsung A05', '250.00', 1, 1),
(16, 'Sous vetements ', 'couleur blanc', '3.00', 1, 3),
(18, 'table', 'pour salon', '60.00', 1, 6),
(19, 'vitre', 'POUR CHAMBRE ', '50.00', 1, 6),
(20, 'lait', 'en poudre ( 1kg)', '2.00', 1, 2);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) DEFAULT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mot_de_passe` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `nom`, `prenom`, `email`, `mot_de_passe`) VALUES
(1, 'diong', 'dame', 'moudoufatim@gmail.com', '$2y$10$slQiMsMYdUmZ4dYBnMG8oOiDQRJL.TNgc1szVIawJfDirFOuMjzwm'),
(2, 'faye', 'mansour', 'fay@gmail.com', '$2y$10$nhYwkNmZ9cq93VjIWjtBouQF6I7ZFzD5mSMTz.ohVL4ROoI3JIHzC'),
(3, 'sall', 'ibrahima', 'sall@gmail.com', '$2y$10$TzHBcU.Q/Zu64/W1a2Pg/u21V3tHRrZHN9SjrZVLb1KlOiSAWc6ny');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_categorie` (`id_categorie`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`id_categorie`) REFERENCES `categories` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
